/*
 COPYRIGHT 2012 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

@class AGSMarkerSymbol;
@class AGSSimpleLineSymbol;

/** @file AGSSimpleMarkerSymbol.h */ //Required for Globals API doc

/**  A marker symbol based on simple shapes.
 
 Instances of this class represent simple marker symbols. Symbols describe how 
 graphics look on the map. Different symbols are used for graphics with different 
 geometry types. Marker symbols are used to display those graphics which are 
 based on point or multipoint geometry. Simple marker symbols display graphics 
 using simple, predefined markers such as circle, cross, etc. In addition, the 
 markers can have an optional outline, which is defined by a line symbol.
 
 
 */
@interface AGSSimpleMarkerSymbol : AGSMarkerSymbol
/** The marker style. Possible values include 
 
 @li  AGSSimpleMarkerSymbolStyleCircle
 @li  AGSSimpleMarkerSymbolStyleCross
 @li  AGSSimpleMarkerSymbolStyleDiamond
 @li  AGSSimpleMarkerSymbolStyleSquare
 @li  AGSSimpleMarkerSymbolStyleX
 @li  AGSSimpleMarkerSymbolStyleTriangle
 
 Default is AGSSimpleMarkerSymbolStyleCircle.
 @since 10.2
 */
@property (nonatomic) AGSSimpleMarkerSymbolStyle style;

/** Outline of the marker.
 @since 10.2
 */
@property (nonatomic, strong) AGSSimpleLineSymbol *outline;

/** Get autoreleased symbol initialized with default values.
 @return A new, autoreleased, marker symbol object.
 @since 10.2
 */
+ (id)simpleMarkerSymbol;

/** Initializes with a color.
 @param color The color to initialize the marker symbol with.
 @since 10.2
 */
-(id)initWithColor:(AGSColor*)color;

/** Get autoreleased simple marker symbol with a color.
 @param color The color to initialize the marker symbol with.
 @since 10.2
 */
+(id)simpleMarkerSymbolWithColor:(AGSColor*)color;
@end
