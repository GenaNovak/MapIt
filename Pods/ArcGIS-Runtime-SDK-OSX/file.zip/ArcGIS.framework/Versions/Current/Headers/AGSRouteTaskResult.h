/*
 COPYRIGHT 2011 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */




/** @file AGSRouteTaskResult.h */

@protocol AGSCoding;

/**  Result of an  AGSRouteTask solve operation.
 
 Instances of this class represent a result of a single  AGSRouteTask solve operation. The result
 is a collection of computed routes, barriers used in the analysis, and messages generated during the analysis.
 
 @since 10.2
 */
@interface AGSRouteTaskResult : NSObject <AGSCoding>

/** Array of  AGSRouteResult objects. Each object represents a separate route with
 independent driving directions. See  routeName property of  AGSRouteTaskParameters to see how to
 group stops into separate routes.
 @since 10.2
 */
@property (nonatomic, copy, readonly) NSArray *routeResults;

/** Array of  AGSGraphic objects representing the point barriers. Barriers are only returned if 
 the <code>returnPointBarriers</code> parameter of  AGSRouteTaskParameters is <code>true</code>.
 @since 10.2
 */
@property (nonatomic, copy, readonly) NSArray *pointBarriers;

/** Array of  AGSGraphic objects representing the polyline barriers. Barriers are only returned if 
 the <code>returnPolylineBarriers</code> parameter of  AGSRouteTaskParameters 
 is <code>true</code>.
 @since 10.2
 */
@property (nonatomic, copy, readonly) NSArray *polylineBarriers;

/** Array of  AGSGraphic objects representing the polygon barriers. Barriers are only returned if 
 the <code>returnPolygonBarriers</code> parameter of  AGSRouteTaskParameters 
 is <code>true</code>.
 @since 10.2
 */
@property (nonatomic, copy, readonly) NSArray *polygonBarriers;

/** Messages received when solve is completed. If a route cannot be solved, the message
 returned by the server identifies the route that could not be solved. This is 
 an array of  AGSNAMessage objects.
 @since 10.2
 */
@property (nonatomic, copy, readonly) NSArray *messages;

@end
